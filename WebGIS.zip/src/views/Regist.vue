<template>
  <div id="container">
    <div id="form" class="basic-shadow el-zoom-in-center">
      <div id="form-header" align="center">
        <text>注册</text>
      </div>
      <el-divider></el-divider>
      <el-form :model="registForm" label-width="110px" >
        <el-form-item label="账号:" required>
          <el-input v-model="registForm.username"></el-input>
        </el-form-item>
        <el-form-item label="密码:" required>
          <el-input v-model="registForm.password" type="password"></el-input>
        </el-form-item>
        <el-form-item label="重复一次密码:" required>
          <el-input v-model="registForm.r_password" type="password"></el-input>
        </el-form-item>
        <el-form-item label="性别:" required>
          <el-radio-group v-model="registForm.gender">
            <el-radio-button label="男" :value="0"></el-radio-button>
            <el-radio-button label="女" :value="1"></el-radio-button>
          </el-radio-group>
        </el-form-item>
        <el-form-item label="生日:" required>
          <div id="date">
            <el-date-picker v-model="registForm.birthday" placeholder="选择日期"></el-date-picker>
          </div>
        </el-form-item>
        <el-form-item label="邮箱:" required>
          <el-input v-model="registForm.email"></el-input>
        </el-form-item>
        <el-form-item label="昵称:" required>
          <el-input v-model="registForm.nickname"></el-input>
        </el-form-item>

        <div align="right">
          <el-space>
            <router-link class="router_link" to="/login">去登录</router-link>
            <el-button type="primary" plain>注册</el-button>
          </el-space>

        </div>
      </el-form>
    </div>
  </div>


</template>

<script>
export default {
  name: "Regist",
  data() {
    return {
      registForm: {
        username: "",
        password: "",
        r_password: "",
        email: "",
        nickname: "",
        gender: "男",
        birthday: ""
      }
    }
  }
}
</script>

<style scoped>
#container{
  width: 100%;
  height: 100%;
  position: absolute;
  background-image: url("./../assets/background1.jpg");
  background-size: cover;
  background-repeat: no-repeat;
}
#form{
  position: relative;
  margin: 0 auto;
  top: 50%;
  transform: translateY(-50%);
  width: 40vw;
  max-width: 500px;
  min-width: 220px;
  padding: 20px 50px;
  background: white;
  border-radius: 4px;
}

#form-header{
  font-size: 20px;
  margin-bottom: 20px;
}
#date{
  width: 100%;
}
</style>