<template>
  <el-container>
    <el-header>

    </el-header>
    <el-row>
      <el-main>
          <div id="sidebar">
            <el-menu
                mode="vertical"
                :router="true"
                :default-active="$route.fullPath==='/index'?'/index/map':$route.fullPath"
                :collapse="true"
            >
              <el-menu-item index="/index/map">
                <i class="el-icon-location"></i>

                <template #title>
                  <span>分享地图</span>
                </template>
              </el-menu-item>
              <el-menu-item index="/index/info" >
                <i class="el-icon-user-solid"></i>
                <template #title>
                  <span>个人信息</span>
                </template>
              </el-menu-item>
              <el-menu-item index="/index/about">
                <i class="el-icon-info"></i>
                <template #title>
                  <span>关于</span>
                </template>
              </el-menu-item>
            </el-menu>
          </div>

        <router-view></router-view>
      </el-main>
    </el-row>


    <el-footer></el-footer>
  </el-container>
</template>

<script>
export default {
  name: "Index"
}
</script>

<style scoped>
.el-container {
  background: #42b983;
}

.el-header {
  background: #3a8ee6;
}


#sidebar {
  background: #e6a23c;
}

#sidebar .el-menu {
  height: calc(100vh - 120px);

}

.el-main {
  background: #d94b84;
  padding: 0;
  display: flex;
}

.el-footer {
  background: #303133;
}


</style>