<template>
  <div id="mapContainer">
    <div id="shareContainer" class="basic-shadow">
      <div>
        <span class="shareTitle">分享</span>
        <i class="el-icon-arrow-up arrow"></i>
      </div>
      <div class="search">
        <el-input v-model="search" placeholder="搜索" size="mini" clearable></el-input>
      </div>
    </div>
    <div class="map_buttons">
      <div class="button_group">
        <el-button size="mini" @click="addPoint">
          <i class="el-icon-add-location"></i>
          分享
        </el-button>
      </div>
    </div>
  </div>
</template>

<script>
import AMapLoader from '@amap/amap-jsapi-loader'
import {onMounted} from "vue";


export default {
  name: "Map",
  data() {
    return {
      search: "",
      map: {},
      amap: {}
    }
  },
  methods: {
    addPoint(e) {
      console.log(this)
      new AMap.MouseTool(this.map)
    }
  },
  mounted() {
    AMapLoader.load({
      "key": "8253644b705e57e861f82f8742d7ae9f"
    }).then((AMap) => {
      this.amap = AMap
      this.map = new AMap.Map('mapContainer')
    }).catch(e => {
      console.error(e)
    })
  }
}
</script>

<style scoped>
#mapContainer {
  width: 100%;
  height: 100%;
  background: #000;
  display: flex;
}

.map_buttons {
  width: 100%;
  z-index: 999;
  position: absolute;
}

.map_buttons .button_group {
  position: relative;
  margin: 10px;
  padding: 10px;
  background: rgba(0, 0, 0, 0.5);
  float: right;

}

#shareContainer {
  height: 100%;
  width: 15vw;
  max-width: 300px;
  min-width: 200px;
  background: white;
  border-radius: 5px;
  z-index: 9999 !important;
  float: left;
}

.arrow {
  margin: 5px 10px;
  float: right;

}

.shareTitle {
  display: inline-block;
  margin-top: 5px;
  margin-left: 10px;
}

.search {
  padding: 10px 20px 10px 10px;

}
</style>