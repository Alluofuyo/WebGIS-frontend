import {createRouter, createWebHashHistory} from "vue-router"


const routes = [
    {
        path: "/",
        component: () => import("@/views/Login.vue"),
        meta:{
            transition:"fade"
        }
    },
    {
        path: "/login",
        component: () => import("@/views/Login.vue"),
        meta:{
            transition:"fade"
        }
    },
    {
        path: "/regist",
        component: () => import("@/views/Regist.vue"),
        meta:{
            transition:"fade"
        }
    },
    {
        path: "/index",
        component: () => import("@/views/Index.vue"),
        meta:{
            transition:""
        },
        children:[
            {
                path:"map",
                component:()=>import("@/views/nav/Map.vue"),
                meta:{
                    transition:"fade"
                }
            },
            {
                path:"info",
                component:()=>import("@/views/nav/Map.vue"),
                meta:{
                    transition:"fade"
                }
            },
            {
                path:"about",
                component:()=>import("@/views/nav/Map.vue"),
                meta:{
                    transition:"fade"
                }
            }
        ]
    }
]

const router = createRouter({
    history: createWebHashHistory(),
    routes
})

export {router}