<template>
  <el-card class="box-card">
    <template #header>
      <div class="card-header">
        <el-avatar size="small" :src="info.avatar" alt="头像"></el-avatar>
        <img :src="info.avatar" alt="头像">
        <span>{{ info.username }}</span>
        <i class="el-icon-close close"></i>
      </div>
    </template>
    <div class="content">
      {{info.content}}
    </div>
    <div class="footer">
      <div>
        <i class="el-icon-location-information"></i>
        <span>{{ info.position }}</span>
      </div>
      <div>
        {{ info.time }}
      </div>
      <a>查看更多>></a>
    </div>
  </el-card>
</template>

<script>
export default {
  name: "ShareCard",
  props: {
    info: {
      username: String,
      avatar: String,
      content: String,
      position: String,
      time: String
    }

  }
}
</script>

<style scoped>

</style>